This ZIP contains the Draft CDISC ODM MetadataUse Case.  It includes the files:

ODMmetaDataUseCase2.doc -- Current Draft of the Use Case document
MetadataUC1.xml -- XML code for Example 1 
MetadataUC2.xml -- XML code for Example 2
MetadataUC3.xml -- XML code for Example 3
UC-AE.pdf -- Blank AE CRF page layout
UC-CONMED.pdf -- Blank ConMed CRF page layout -- sample only
UC-DEMOG.pdf -- Blank DEMOG CRF page layout -- sample only
UC-DRUG_TRT.pdf -- Blank Drug Treatment CRF Page layout -- sample only
UC-PHARM01.pdf -- Blank PHARM CRF page layout -- sample only
UC-PHYSEX.pdf -- Blank Physical Exam CRF page layout -- sample only
odm1-1-0.dtd -- CDISC ODM dtd
ReadMe.txt -- this file

To be able to view the example XML files, you need to extract all the files into a single folder.  